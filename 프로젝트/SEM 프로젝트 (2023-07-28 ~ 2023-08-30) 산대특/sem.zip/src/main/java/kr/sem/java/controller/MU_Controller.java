package kr.sem.java.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import kr.sem.java.service.Rm_Service;
import kr.sem.java.vo.semVO;

@Controller
public class MU_Controller {

	@Autowired
	Rm_Service RmService;
	
	
	//=========================����� ���������� ȸ��������ȸ======================================
	   @RequestMapping(value="/rmmain/udetail")
	   public String uselectOneBoard(@RequestParam(required = true) String sno, Model model) {
		   System.out.println("����� ����ȸ");
		   System.out.println("username >>" + sno);
		   List<semVO> RudList = RmService.uselectOneBoard(sno);
		   System.out.println("RudList >>" + RudList);
		   model.addAttribute("RudList",RudList);
		   return "/user/Mu_List";
	   }
}
