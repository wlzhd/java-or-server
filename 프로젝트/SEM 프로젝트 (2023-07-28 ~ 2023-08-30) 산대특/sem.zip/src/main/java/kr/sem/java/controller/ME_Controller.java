package kr.sem.java.controller;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import kr.sem.java.service.Rm_Service;
import kr.sem.java.vo.semmenuVO;

@RequestMapping("/menu/*")
@Controller
public class ME_Controller {

	@Autowired
	Rm_Service RmService;

	@RequestMapping(value = "/Me_Insert")
	public String MenuInster() {
		System.out.println("Me_Inster �Լ� ����");
		return "/menu/Me_Insert";
	}

	@PostMapping(value = "/menu/InsertOK")
	public String menuInsertOK(@ModelAttribute semmenuVO mvo, @RequestParam("s_file") MultipartFile s_file,
			String s_mno) throws Exception {

		System.out.println("ME_Controller/menuInsertOK");
		System.out.println("s_mno > " + s_mno);
		semmenuVO aaa = new semmenuVO();
		aaa.setS_mno(s_mno);
		// ���� ���ε� ����
		String uploadPath = "/home/jikong01/ROOT/resources/img/"; 
		//String uploadPath = "C:\\javaPro\\20.spring\\sem\\src\\main\\webapp\\resources\\img"; // ���� ���� ���
		String b_orgfname = s_file.getOriginalFilename();
		String extension = StringUtils.getFilenameExtension(b_orgfname);

		Calendar cal = Calendar.getInstance();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmSS");

		String time = dateFormat.format(cal.getTime());
		String b_refname = time + "." + extension;
		System.out.println("b_refname >> " + b_refname);
		File uploadFile = new File(uploadPath, b_refname);
		s_file.transferTo(uploadFile);

		// DB�� ���� ���� ���� ����
		mvo.setS_mno(s_mno);
		mvo.setS_orgfname(b_orgfname);
		mvo.setS_refname(b_refname);
		mvo.setS_imagepath(uploadPath);
		System.out.println("mvo >> " + mvo.getS_mno());

		// �޴� ���� �߰� ����
		int result = RmService.menuInsert(mvo);

		if (result != 1) {
			System.out.println("�޴� �߰��� �����Ͽ����ϴ�.");
			return "redirect:/menu/Insert";
		}
		//return "test";
		// ������ ���� �߰�
		return "redirect:/master/Ms_List?sno="+mvo.getS_mno();
	}
	
	   // �޴� ����
	   @GetMapping(value = "/menu/deletes")
	   public String menudelete(@RequestParam(required = true) String s_no) throws Exception {
	      System.out.println("ME_Controller/menudelete");
	      System.out.println("s_no > " + s_no);
	      int result = RmService.menudelete(s_no);
	      System.out.println("result >>" + result);
	      return "null";
	   }
	   
	   // �޴� ����
	   @RequestMapping(value = "/menu/updates")
	   public String menuupdates(String s_sno, Model model) throws Exception {
	      System.out.println("ME_Controller/menuupdates");
	      System.out.println("s_sno > " + s_sno);
	      List<semmenuVO> RmdList = RmService.MeselectOneList(s_sno);
	      System.out.println("RmdList >>" + RmdList);
	      model.addAttribute("RmdList", RmdList);
	      return "/menu/Me_Update";
	   }

	   @RequestMapping(value = "/menu/updatesOk", method = RequestMethod.POST)
	   public String menuupdatesOk(String s_mno, String s_sno, String s_name,String s_price,
	         MultipartHttpServletRequest multipartRequest, semmenuVO mvo, RedirectAttributes rattr)
	         throws Exception {
	      System.out.println("ME_Controller/menuupdatesOk");
	      mvo.setS_sno(s_sno);
	      mvo.setS_mname(s_name);
	      mvo.setS_mprice(s_price);
	      // ���� ���ε� ó�� ����
	      MultipartFile file = multipartRequest.getFile("s_file");
	      if (!file.isEmpty()) {
	         String orgfilename = file.getOriginalFilename();
	         String savepath = "/home/jikong01/ROOT/resources/img/"; // ������ �ø���
	         //String savepath = "C:\\javaPro\\20.spring\\sem\\src\\main\\webapp\\resources\\img";
	         
	         String extension = StringUtils.getFilenameExtension(orgfilename);

	         Calendar cal = Calendar.getInstance();
	         SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmSS");
	         String time = dateFormat.format(cal.getTime());
	         String refFileName = time + "." + extension;

	         File uploadfile = new File(savepath, refFileName);
	         try {
	            file.transferTo(uploadfile);
	         } catch (IOException e) {
	            e.printStackTrace();
	         }
	         
	         mvo.setS_orgfname(orgfilename);
	         mvo.setS_refname(refFileName);
	         mvo.setS_path("/images/");
	         mvo.setS_imagepath(savepath);
	      }

	      // �޴� ���� ������Ʈ
	      int result = RmService.menuupdatesOk(mvo);
	      System.out.println(result);
	      String msg = "";
	      msg = "MENUUPDATE_OK";
	      rattr.addFlashAttribute("msg", msg);
	      
	      return "redirect:/master/Ms_List?sno=" + s_mno;
	   }
	   

}