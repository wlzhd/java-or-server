package kr.sem.java.controller;

import java.io.File;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import kr.sem.java.comm.ChaebunClass;
import kr.sem.java.comm.EncryptionUtils;
import kr.sem.java.service.Rm_Service;
import kr.sem.java.vo.semVO;
import lombok.extern.log4j.Log4j;

@RequestMapping("/auth/*")
@Controller
public class Lg_Controller {
	@Autowired
	private Rm_Service RmService;

	@RequestMapping("/logForm")
	public String loginForm() {
		return "/auth/Login";
	}

	// =====================아이디찾기==========================
	@RequestMapping(value="idcheck")
	   @ResponseBody
	   public String idcheck(@RequestParam(required=true) String s_name, String s_phone) throws Exception {
	      System.out.println("idcheck 함수진입");
	      semVO sno = new semVO();
	      sno.setS_name(s_name);
	      sno.setS_phone(s_phone);
	      List<semVO> sList = RmService.idCheck(sno);
	      System.out.println("sList >> " + sList);
	      String s_id = null;
	      if(sList.size() == 1) {
	         System.out.print("성공");
	         s_id = sList.get(0).getS_id();
	         System.out.print(s_id);
	      }else {
	         System.out.print("error");
	         s_id = sList.get(0).getS_id();
	         System.out.print(s_id);
	      }
	      return s_id;
	   }

	// ==============================비밀번호 찾기====================================
	@RequestMapping(value = "pwcheck")
	@ResponseBody
	public String pwcheck(@RequestParam(required = true) String s_name, String s_id, String s_phone) throws Exception {
		System.out.println("pwcheck 함수진입");

		System.out.println("s_name > " + s_name);
		System.out.println("s_id > " + s_id);
		System.out.println("s_phone > " + s_phone);

		semVO sno = new semVO();
		sno.setS_id(s_id);
		sno.setS_name(s_name);
		sno.setS_phone(s_phone);
		List<semVO> sList = RmService.pwCheck(sno);
		System.out.println("sList >> " + sList);
		String s_pw = null;
		if (sList.size() == 1) {
			System.out.println("성공");
			s_pw = sList.get(0).getS_pass();
			System.out.print(s_pw);
		} else {
			System.out.println("error");
			s_pw = sList.get(0).getS_pass();
			System.out.print(s_pw);
		}
		return s_pw;
	}

	@RequestMapping(value = "/pwupdate")
	public String pwupdate(semVO sno) {
		System.out.println("비밀번호수정");
		System.out.println("s_pw >> " + sno.getS_pass());
		System.out.println("s_pw >> " + sno.getS_pass());
		sno.setS_pass(EncryptionUtils.encryptMD5(sno.getS_pass()));
		System.out.println(">>>>>" + sno.getS_pass());
		int result = RmService.passUpdate(sno);
		System.out.println("result > " + result);
		return "redirect:/";
	}

	// ========================================================
	@GetMapping("/Ji_write") // 회원가입 선택란
	public String Ji_write() {
		return "/auth/Ji_write";
	}

	@RequestMapping(value = "/UserWrite")
	public String UserWrite() {
		System.out.println("회원가입글작성");
		return "/auth/UserWrite";
	}

	@GetMapping("/MasterWrite") // 사업자 회원가입
	public String MasterWrite() {
		System.out.println("사업자회원가입");
		return "/auth/MasterWrite";
	}
	// ====================================================================

	@RequestMapping(value = "/rmmain/idfind")
	public String IdFindBoard(@RequestParam(required = true) String sno, Model model) {
		System.out.println("사업자 상세조회");
		System.out.println("bsname >>" + sno);
		List<semVO> RmdList = RmService.RmselectOneBoard(sno);
		System.out.println("RmdList >>" + RmdList);
		model.addAttribute("RmdList", RmdList);
		return "auth/logForm";
	}

	// ==============================회원==================================
	@PostMapping(value = "/auth/add")
	public String userInsert(@ModelAttribute semVO sno, HttpServletRequest request, HttpServletResponse response,
			RedirectAttributes rattr) throws Exception {

		System.out.println("s_pw >> " + sno.getS_pass());
		sno.setS_pass(EncryptionUtils.encryptMD5(sno.getS_pass()));
		System.out.println(">>>>>" + sno.getS_pass());

		String maxno = RmService.userCommNo();
		String s_no = ChaebunClass.userNo(maxno); // 채번생성 M2023070001
		System.out.println("s_no >> " + s_no);
		sno.setS_no(s_no);

		int result = RmService.userInsert(sno);
		System.out.println("result >>" + result);
		String msg = "";
		if (result != 1) {
			msg = "USER_ERR";
			rattr.addFlashAttribute("msg", msg);
			return "redirect:/auth/write";
		}
		msg = "USER_OK";
		rattr.addFlashAttribute("msg", msg);
		return "redirect:/";
	}

	@PostMapping(value = "/auth/masteradd")
	   public String masterInsert(@ModelAttribute semVO sno, @RequestParam MultipartFile sm_file,
	         HttpServletRequest request, HttpServletResponse response, RedirectAttributes rattr) throws Exception {

	      System.out.println("s_pw >> " + sno.getS_pass());
	      sno.setS_pass(EncryptionUtils.encryptMD5(sno.getS_pass()));
	      System.out.println(">>>>>" + sno.getS_pass());

	      String maxno = RmService.masterCommNo();
	      System.out.println("maxno  >> " + maxno);
	      String s_no = ChaebunClass.masterNo(maxno); // 채번생성 M2023070001
	      
	      System.out.println("s_no >> " + s_no);
	      sno.setS_no(s_no);
	      String s_mfpath = "/home/jikong01/ROOT/resources/img/"; // 서버에 올릴때
	      //String s_mfpath = "C:\\javaPro\\20.spring\\sem\\src\\main\\webapp\\resources\\img";
	      String s_morgfnmae = sm_file.getOriginalFilename();
	      System.out.println("s_morgfnmae >> " + s_morgfnmae);
	      String extension = StringUtils.getFilenameExtension(sm_file.getOriginalFilename()); // 확장자명만 들어감

	      // 중복된 파일명 업로드시 덮어쓰기 방지를 위해 실제 서버에 저장되는 파일은
	      // 업로드하는 현재 시간을 파일명으로 변경하여 저장
	      Calendar cal = Calendar.getInstance();
	      SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmSS");
	      String time = dateFormat.format(cal.getTime());

	      String s_mrefname = time + "." + extension;
	      File uploadPath = new File(s_mfpath, s_mrefname);

	      // 새로 작성한 파일명으로 서버 업로드
	      sm_file.transferTo(uploadPath);
	      // DB에 파일명, 새로작성한 파일명, 파일경로 저장하기 위해 객체에 데이터 추가
	      sno.setS_morgfnmae(s_morgfnmae);
	      sno.setS_mrefname(s_mrefname);
	      sno.setS_mfpath(s_mfpath);
	      sno.setS_image("/images/");
	      

	      int result = RmService.masterInsert(sno);
	      System.out.println("result >>" + result);
	      String msg = "";
	      if (result != 1) {
	         msg = "MASTER_ERR";
	         rattr.addFlashAttribute("msg", msg);
	         return "redirect:/auth/write";
	      }
	      msg = "MASTER_OK";
	      rattr.addFlashAttribute("msg", msg);
	      return "redirect:/";
	   }

	// ==================================================로그인구성===================================================

	@PostMapping("/Login")
	public String userCheck(String s_id, String s_upwr, String s_authority, HttpServletRequest request,
			HttpServletResponse response, RedirectAttributes rattr) throws Exception {

		semVO user = new semVO();
		List<semVO> ulist = null;
		System.out.println("user >>" + user);

		user.setS_id(s_id);
		ulist = RmService.loginselect(user);
		System.out.println("ulist > " + ulist);
		String msg = "";
		
	      if (ulist.size() == 0) {
	          msg = "아이디가 일치하지 않습니다";
	          response.setContentType("text/html; charset=UTF-8");
	          PrintWriter out = response.getWriter();
	          out.println("<script>alert('" + msg + "');location.href='/sem/auth/logForm';</script>");
	          out.flush();
	          return "redirect:/sem/auth/logForm";
	       }

		HttpSession session = null;
		session = request.getSession();
		if (ulist.size() == 1) {
			String upwr_ = EncryptionUtils.encryptMD5(s_upwr);
			String upw = ulist.get(0).getS_pass();

			if (upw.equals(upwr_) && ulist.get(0).getS_authority().equals("R")
				|| upw.equals(upwr_) && ulist.get(0).getS_authority().equals("M")
				|| upw.equals(upwr_) && ulist.get(0).getS_authority().equals("U")) {
				System.out.println("일치");
				session.setAttribute("sno", ulist.get(0).getS_no());
				session.setAttribute("sid", ulist.get(0).getS_id());
				session.setAttribute("sname", ulist.get(0).getS_name());
				session.setAttribute("sauthority", ulist.get(0).getS_authority());
				System.out.println(ulist.get(0).getS_authority());
				String msa = ulist.get(0).getS_name() + "님 환영합니다";
				response.setContentType("text/html; charset=UTF-8");
				PrintWriter out = response.getWriter();
				out.println("<script>alert('" + msa + "');location.href='/sem';</script>");
				out.flush();
			} else if (ulist.get(0).getS_authority().equals("N")) {
				String mss = "존재하지않은 계정입니다. \\n 회원가입 해주시길바랍니다.";
				response.setContentType("text/html; charset=UTF-8");
				PrintWriter out = response.getWriter();
				session.invalidate();
				out.println("<script>alert('" + mss + "');location.href='/sem/auth/logForm';</script>");
				out.flush();
				return "redirect:/";
			} else {
				String mss = "패스워드가 일치하지 않습니다. \\n 다시 시도해 주세요";
				response.setContentType("text/html; charset=UTF-8");
				PrintWriter out = response.getWriter();
				out.println("<script>alert('" + mss + "');location.href='/sem/auth/logForm';</script>");
				out.flush();
				return "redirect:/";
			}
		}

		return "redirect:/";
	}

	@GetMapping("/logout")
	public String logout(HttpSession session, HttpServletResponse response) throws Exception {
		System.out.println("logout");
		String mss = "로그아웃이 완료되었습니다.";
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.println("<script>alert('" + mss + "');location.href='/sem';</script>");
		session.invalidate();
		out.flush();
		return "redirect:/";
	}
	
	// ==================================================아이디 중복===================================================
	
	@RequestMapping(value = "/auth/Write", method = RequestMethod.GET)
	@ResponseBody
	public String useridCheck(@RequestParam("sid") String sid) {
		System.out.println("sid111 >> " + sid);
		int bList = RmService.userIdCheck(sid);
		System.out.println("sid >> " + bList);
		return String.valueOf(bList);
	}

	@RequestMapping(value = "/auth/masterWrite", method = RequestMethod.GET)
	@ResponseBody
	public String masteridCheck(@RequestParam("sid") String sid) {
		System.out.println("sid111 >> " + sid);
		int bList = RmService.masterIdCheck(sid);
		System.out.println("sid >> " + bList);
		return String.valueOf(bList);
	}

}
