package kr.sem.java.comm;

import java.util.Calendar;

public class ChaebunClass {
   public static final String USER = "U";
   public static final String MASTER = "M";
   public static final String BOARD = "B";
   public static String calendarNo(){
         String commDate = "";
         int commYEAR_ = 0;
         int commMONTH_ = 0;
         int commDAY_ = 0;
         String commYEAR = "";
         String commMONTH = "";
         String commDAY = "";
         
         Calendar cl =  Calendar.getInstance();//���� ���� ���� ���
         commYEAR_ = cl.get(Calendar.YEAR);
         commMONTH_ = cl.get(Calendar.MONTH)+1; // 0~11
         commDAY_ = cl.get(Calendar.DAY_OF_MONTH);
         
         commYEAR = String.valueOf(commYEAR_);
         commMONTH = String.valueOf(commMONTH_);
         commDAY = String.valueOf(commDAY_);
         
         if(commMONTH_ < 10){
            commMONTH = "0" + String.valueOf(commMONTH_);
         }
         System.out.println("���� �� : " + commYEAR);
         System.out.println("���� �� : " + commMONTH);
         System.out.println("���� �� : " + commDAY);
         
         if(commDAY_ < 10){
            commDAY = "0" + String.valueOf(commDAY_);
         }
         System.out.println("���� �� : " + commYEAR);
         System.out.println("���� �� : " + commMONTH);
         System.out.println("���� �� : " + commDAY);
         commDate = commYEAR + commMONTH + commDAY;
         
         System.out.println("commDate = "+ commDate);
         return commDate;
      }
      public static String commMaxNo(String maxno){
         System.out.println("ChaeBunClass commMaxNo( )�Լ� ����");
         System.out.println("maxno = " + maxno);
         //ȸ�� ��ȣ�� �ִ밪�� ��������
         String commNO = "";
         commNO = maxno; 
         System.out.println("commNO = " + commNO);
         
         if(1 == commNO.length()){
            commNO = "00"+maxno;
         }
         if(2 == commNO.length()){
            commNO = "0" + maxno;
         }
          
         System.out.println("commNO = " + commNO);
         return commNO;
      }
      public static String userNo(String maxno){ //�Խ��� ä������
         String commNO = null;
         commNO = ChaebunClass.USER
               + ChaebunClass.calendarNo()
               + ChaebunClass.commMaxNo(maxno);
         return commNO;
      }
      public static String masterNo(String maxno){ //�Խ��� ä������
          String commNO = null;
          commNO = ChaebunClass.MASTER
                + ChaebunClass.calendarNo()
                + ChaebunClass.commMaxNo(maxno);
          return commNO;
       }
   //   public static void main(String args[]) {
//         String chaebun = ChaeBunClass.userNO("1");
//         System.out.println(chaebun);
   //   }
   }