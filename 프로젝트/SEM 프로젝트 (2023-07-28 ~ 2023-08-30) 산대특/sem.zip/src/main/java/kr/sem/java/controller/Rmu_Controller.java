package kr.sem.java.controller;

import java.io.PrintWriter;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import kr.sem.java.vo.PageHandler;
import kr.sem.java.vo.RmSearchCondition;
import kr.sem.java.vo.semVO;
import kr.sem.java.service.Rm_Service;

@Controller

public class Rmu_Controller {
	@Autowired
	Rm_Service RmService;
	
	@ExceptionHandler(Exception.class)
	public String errorPage(Exception e) {
		e.printStackTrace();
		return "error";
	}

	// ===============================����� ����� ����Ʈ ��ȸ===============================
	@RequestMapping(value = "/rmmain/Rm_list")
	public String RmselectAllBoard(Model model) {
		List<semVO> RmList = RmService.RmselectAllBoard();
		System.out.println("����� ��ü��ȸ");
		System.out.println("RmList >>" + RmList);
		model.addAttribute("RmList", RmList);
		return "rmmain/Rm_list";
	}

	@RequestMapping(value = "/rmmain/rmdetail")
	public String RmselectOneBoard(@RequestParam(required = true) String sno, Model model) {
		System.out.println("����� ����ȸ");
		System.out.println("bsname >>" + sno);
		List<semVO> RmdList = RmService.RmselectOneBoard(sno);
		System.out.println("RmdList >>" + RmdList);
		model.addAttribute("RmdList", RmdList);
		return "rmmain/rmdetail";
	}

	// ===============================����� ����� ����Ʈ ��ȸ===============================
	@RequestMapping(value = "/rmmain/Ru_list")
	public String RuselectAllBoard(Model model) {
		List<semVO> RuList = RmService.RuselectAllBoard();
		System.out.println("����� ��ü��ȸ");
		System.out.println("RuList >>" + RuList);
		model.addAttribute("RuList", RuList);
		return "rmmain/Ru_list";
	}

	@RequestMapping(value = "/rmmain/rudetail")
	public String RuselectOneBoard(@RequestParam(required = true) String sno, Model model) {
		System.out.println("����� ����ȸ");
		System.out.println("username >>" + sno);
		List<semVO> RudList = RmService.RuselectOneBoard(sno);
		System.out.println("RudList >>" + RudList);
		model.addAttribute("RudList", RudList);
		return "rmmain/rmdetail";
	}

	// ==========================����� ȸ����������Ȯ�� ����Ʈ ��ȸ=============================
	@RequestMapping(value = "/rmmain/Rn_list")
	public String RmDeleteCheckBoard(Model model) {
		List<semVO> RnList = RmService.RmDeleteCheckBoard();
		System.out.println("�����,����� ����������ȸ");
		System.out.println("RnList >>" + RnList);
		model.addAttribute("RnList", RnList);
		return "rmmain/Rn_list";
	}

	// =========================����� ����ڼ��� ����Ʈ��ȸ==========================

	@GetMapping(value = "/rmmain/update")
	public String RmuUpdate(@RequestParam(required = true) String sno, Model model) {
		System.out.println("sno !!!!>> " + sno);
		List<semVO> bList = RmService.RmselectOneBoard(sno);
		System.out.println("bList !!!!>>" + bList);
		if (bList == null) {
			return "error";
		}
		model.addAttribute("bList", bList);
		return "/rmmain/Rm_update";
	}

	@PostMapping(value = "/rmmain/updateOK")
	public String updateBoard(@ModelAttribute semVO svo, HttpServletRequest request, HttpServletResponse response
			,RedirectAttributes rattr) {
		System.out.println("�Խñ� ����");
		int result = RmService.updateBoard(svo);
		System.out.println("result >>" + result);
		if (result != 1) {
			return "error";

		}
	    String msg = "";
	    msg = "MUPDATE_OK";
	    rattr.addFlashAttribute("msg", msg);
		
		return "redirect:/master/Mm_List?sno=" + svo.getS_no();
	}

	// ========================����� ����ڼ��� ����Ʈ��ȸ===========================
	@GetMapping(value = "/rmmain/uupdate")
	public String uUpdate(@RequestParam(required = true) String sno, Model model ) {
		System.out.println("sno !!!!>> " + sno);
		List<semVO> bList = RmService.RuselectOneBoard(sno);
		System.out.println("bList !!!!>>" + bList);
		if (bList == null) {
			return "error";
		}
		model.addAttribute("bList", bList);
		return "/rmmain/Ru_update";
	}

	@PostMapping(value = "/rmmain/uupdateOK")
	public String uupdateBoard(@ModelAttribute semVO svo, HttpServletRequest request,  RedirectAttributes rattr) {
		System.out.println("�Խñ� ����");
		int result = RmService.uupdateBoard(svo);
		System.out.println("result >>" + result);
		if (result != 1) {
			return "error";
			
		}
	    String msg = "";
	    msg = "UUPDATE_OK";
	    rattr.addFlashAttribute("msg", msg);
	    
		return "redirect:/rmmain/udetail?sno=" + svo.getS_no();
	}

	// ===============================����� ȸ������ ��¥! ��ȸ===============================
	@RequestMapping(value = "/rmmain/reallyDelete")
	public String RmreallyDelete(@RequestParam(required = true) String sno, RedirectAttributes rattr) {
		System.out.println("ȸ������ ��¥ ����");
		int result = RmService.RmreallyDelete(sno);
		System.out.println("result >>" + result);
	      String msg = "";
	      msg = "OK";
	      rattr.addFlashAttribute("msg", msg);
		return "redirect:/rmmain/Rn_list";
	}

	// ===============================����� ȸ������ ��ȸ===============================
	   @GetMapping(value = "/rmmain/delete")
	   public String RmDelete(@RequestParam(required = true) String sno, HttpServletRequest request,
	         RedirectAttributes rattr, HttpSession session, HttpServletResponse response) throws Exception {
	      System.out.println("ȸ�� ����");
	      int result = RmService.RmDelete(sno);
	      int result1 = RmService.menuRmDelete(sno);
	      System.out.println("result >>" + result);
	      System.out.println("result1 >>" + result1);
	      String msg = "";
	      if (result != 1) {
	         msg = "DEL_ERR";
	      } else {
	         msg = "DEL_OK";
	      }
	      String mss = "ȸ��Ż���ϼ̽��ϴ�.";
	      response.setContentType("text/html; charset=UTF-8");
	      PrintWriter out = response.getWriter();
	      out.println("<script>alert('" + mss + "');location.href='/';</script>");
	      session.invalidate();
	      rattr.addFlashAttribute("msg", msg); // �˸�â ����
	      out.flush();
	      return "redirect:/";
	   }

	
	@RequestMapping(value = "/rmmain/rndetail")
	   public String RmDeleteCheckOneBoard(@RequestParam(required = true) String sno, Model model) {
	      System.out.println("����� ����ȸ");
	      System.out.println("username >>" + sno);
	      List<semVO> RndList = RmService.RmDeleteCheckOneBoard(sno);
	      System.out.println("RndList >>" + RndList);
	      model.addAttribute("RndList", RndList);
	      return "rmmain/rmdetail";
	   }

}