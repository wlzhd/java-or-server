package kr.sem.java.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import kr.sem.java.mapper.Rm_Mapper;
import kr.sem.java.vo.RmSearchCondition;
import kr.sem.java.vo.semVO;
import kr.sem.java.vo.semmenuVO;

@Service
public class Rm_ServiceImpl implements Rm_Service { // ����� ����� ���� �Դϴ�

	@Autowired
	Rm_Mapper Rmmapper;

	@Override
    public int menuRmDelete(String sno) {
       // TODO Auto-generated method stub
       System.out.println("RmServiceImpl menuRmDelete�Լ� ���� ========>");
       int result = Rmmapper.menuRmDelete(sno);
       return result;
    }
	
	@Override
	public int getPageCnt(RmSearchCondition rsc) {
		// TODO Auto-generated method stub
		System.out.println("RmServiceImpl getPageCnt�Լ� ����");
		int toalCnt = Rmmapper.getPageCnt(rsc);
		return toalCnt;
	}

	// ======================���̵� ã��======================
	@Override
	public List<semVO> idCheck(semVO sno) throws Exception {
		System.out.println("Rm_ServiceImpl idCheck �Լ�����");
		return Rmmapper.idCheck(sno);
	}

	// ======================��й�ȣ ã��======================
	@Override
	public List<semVO> pwCheck(semVO sno) throws Exception {
		// System.out.println("sno > " + sno);
		System.out.println("Rm_ServiceImpl pwCheck �Լ�����");
		return Rmmapper.pwCheck(sno);
	}

	@Override
	public int passUpdate(semVO sno) {
		// TODO Auto-generated method stub
		System.out.println("RmServiceImpl passInsert �Լ�����---------------");
		int nCnt = Rmmapper.passUpdate(sno);
		System.out.println("nCnt = " + nCnt);
		return nCnt;
	}
	// ==================================================

	@Override
	public int MasterTime(semmenuVO sno) {
		// TODO Auto-generated method stub
		System.out.println("Rm_ServiceImpl MasterTime�Լ� ���� ========>");
		int result = Rmmapper.MasterTime(sno);
		System.out.println("result>>" + result);
		return result;
	}

	@Override
	public int MasterTable(semmenuVO sno) {
		// TODO Auto-generated method stub
		System.out.println("Rm_ServiceImpl MasterTable�Լ� ���� ========>");
		int Tableresult = Rmmapper.MasterTable(sno);
		System.out.println("Tableresult >>" + Tableresult);
		return Tableresult;
	}

	// ==================================================

	@Override
	public List<semVO> RmselectAllBoard() {
		// TODO Auto-generated method stub
		System.out.println("===========Rm_ServiceImpl selectAllBoard �Լ� ���� ===========");
		List<semVO> RmList = Rmmapper.RmselectAllBoard();
		System.out.println("RmList >>" + RmList);
		return RmList;
	}

	@Override
	public List<semVO> RmselectOneBoard(String sno) {
		// TODO Auto-generated method stub
		System.out.println("===========Rm_ServiceImpl RmselectOneBoard �Լ� ���� ===========");
		List<semVO> bsList = Rmmapper.RmselectOneBoard(sno);

		System.out.println("bsList >>" + bsList);
		return bsList;
	}

	// =======================================================================================================

	public List<semVO> RuselectAllBoard() {
		// TODO Auto-generated method stub
		System.out.println("===========Ru_ServiceImpl RuselectAllBoard �Լ� ���� ===========");
		List<semVO> RuList = Rmmapper.RuselectAllBoard();
		System.out.println("RuList >>" + RuList);
		return RuList;
	}

	@Override
	public List<semVO> RuselectOneBoard(String sno) {
		// TODO Auto-generated method stub
		System.out.println("==========Ru_ServiceImpl RuselectDetailBoard �Լ� ���� ===========");
		List<semVO> buList = Rmmapper.RuselectOneBoard(sno);

		System.out.println("buList >>" + buList);
		return buList;
	}

	// =====================================�����, �����
	// �������Ȯ��==================================
	@Override
	public List<semVO> RmDeleteCheckBoard() {
		// TODO Auto-generated method stub
		System.out.println("===========Rn_ServiceImpl RmDeleteCheckBoard �Լ� ���� ===========");
		List<semVO> RnList = Rmmapper.RmDeleteCheckBoard();
		System.out.println("RnList >>" + RnList);
		return RnList;
	}

	@Override
	public List<semVO> RmDeleteCheckOneBoard(String sno) {
		// TODO Auto-generated method stub
		System.out.println("==========Ru_ServiceImpl RmDeleteCheckOneBoard �Լ� ���� ===========");
		List<semVO> bnList = Rmmapper.RmDeleteCheckOneBoard(sno);

		System.out.println("bnList >>" + bnList);
		return bnList;
	}
	// =====================================����ȸ������===============================================

	@Override
	public int userInsert(semVO sno) {
		// TODO Auto-generated method stub
		System.out.println("RmServiceImpl userInsert �Լ�����---------------");
		int nCnt = Rmmapper.userInsert(sno);
		System.out.println("nCnt = " + nCnt);
		return nCnt;
	}

	@Override
	public String userCommNo() {
		// TODO Auto-generated method stub
		System.out.println("RmServiceImpl userCommNO �Լ�����---------------");
		String commNo = Rmmapper.userCommNo();
		System.out.println("commNo = " + commNo);
		return commNo;
	}

	@Override
	public int RmuUpdate(semVO sno) {
		// TODO Auto-generated method stub
		System.out.println("Rm_ServiceImpl RmuUpdate�Լ� ���� ========>");
		int result = Rmmapper.RmuUpdate(sno);
		return result;
	}

	@Override
	public int updateBoard(semVO svo) {
		// TODO Auto-generated method stub
		System.out.println("Rm_ServiceImpl updateBoard�Լ� ���� ========>");
		int result = Rmmapper.UpdateBoard(svo);
		return result;
	}

	@Override
	public int uupdateBoard(semVO svo) {
		// TODO Auto-generated method stub
		System.out.println("Rm_ServiceImpl updateBoard�Լ� ���� ========>");
		int result = Rmmapper.UUpdateBoard(svo);
		return result;
	}

	// =======================================================================================================
	@Override
	public semVO get(String sno) {
		System.out.println("==========Ru_ServiceImpl read �Լ� ���� ===========");
		semVO buList = Rmmapper.read(sno);
		return buList;
	}

	@Override
	public int RmDelete(String sno) {
		// TODO Auto-generated method stub
		System.out.println("RmServiceImpl deleteBoard�Լ� ���� ========>");
		int result = Rmmapper.RmDelete(sno);
		return result;
	}

	@Override
	public int RmreallyDelete(String sno) {
		// TODO Auto-generated method stub
		System.out.println("========== RmServiceImpl RmreallyDelete �Լ� ���� ============");
		int result = Rmmapper.RmreallyDelete(sno);
		return result;
	}
	// =========================================================================================================

	@Override
	public String masterCommNo() {
		// TODO Auto-generated method stub
		System.out.println("RmServiceImpl masterCommNO �Լ�����---------------");
		String commNo = Rmmapper.masterCommNo();
		System.out.println("commNo = " + commNo);
		return commNo;

	}

	@Override
	public int masterInsert(semVO sno) {
		// TODO Auto-generated method stub
		System.out.println("RmServiceImpl masterInsert �Լ�����---------------");
		int nCnt = Rmmapper.masterInsert(sno);
		System.out.println("nCnt = " + nCnt);
		return nCnt;
	}

	// =========================================================================================================

	@Override
	public List<semVO> loginselect(semVO user) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("====================RmServiceImpl loginselect ====================");
		List<semVO> ulist = Rmmapper.loginselect(user);
		return ulist;
	}

	// =========================================================================================================

	@Override
	public List<semVO> MasterMmOneList(String sno) {
		// TODO Auto-generated method stub
		System.out.println("===========Rm_ServiceImpl MasterMmOneList===========");
		List<semVO> bsList = Rmmapper.MasterMmOneList(sno);

		System.out.println("bsList >>" + bsList);
		return bsList;
	}

	@Override
	public List<semVO> uselectOneBoard(String sno) {
		// TODO Auto-generated method stub
		System.out.println("===========Ru_ServiceImpl uselectDetailBoard�Լ� ���� ===========");
		List<semVO> RuList = Rmmapper.uselectOneBoard(sno);
		System.out.println("RuList >>" + RuList);
		return RuList;
	}

	@Override
	public int menuInsert(semmenuVO sno) {
		// TODO Auto-generated method stub
		System.out.println("RmServiceImpl menuInsert �Լ�����---------------");
		int nCnt = Rmmapper.menuInsert(sno);
		System.out.println("nCnt = " + nCnt);
		return nCnt;
	}

	@Override
	public List<semmenuVO> MasterMs_List(String s_mno) {
		// TODO Auto-generated method stub
		System.out.println("===========Rm_ServiceImpl MasterMs_List �Լ� ���� ===========");
		List<semmenuVO> RmList = Rmmapper.MasterMs_List(s_mno);
		System.out.println("RmList >>" + RmList);
		return RmList;
	}

	@Override
	public List<semmenuVO> MasterMain_list() {
		// TODO Auto-generated method stub
		System.out.println("===========Rm_ServiceImpl MasterMain_list �Լ� ���� ===========");
		List<semmenuVO> RmList = Rmmapper.MasterMain_list();
		System.out.println("RmList >>" + RmList);
		return RmList;
	}

	@Override
	public List<semmenuVO> MasterMain2_list(String s_sno) {
		// TODO Auto-generated method stub
		System.out.println("===========Rm_ServiceImpl MasterMain2_list �Լ� ���� ===========");
		List<semmenuVO> RmList = Rmmapper.MasterMain2_list(s_sno);
		System.out.println("RmList >>" + RmList);
		return RmList;
	}

	@Override
	public int menudelete(String s_no) {
		// TODO Auto-generated method stub
		System.out.println("========== RmServiceImpl menudelete �Լ� ���� ============");
		int result = Rmmapper.menudelete(s_no);
		return result;
	}

	@Override
	public List<semmenuVO> MeselectOneList(String s_sno) {
		// TODO Auto-generated method stub
		System.out.println("===========Rm_ServiceImpl MeselectOneList �Լ� ���� ===========");
		List<semmenuVO> bsList = Rmmapper.MeselectOneList(s_sno);
		System.out.println("bsList >>" + bsList);
		return bsList;
	}

	@Override
	public int menuupdatesOk(semmenuVO sno) {
		System.out.println("Rm_ServiceImpl menuupdatesOk�Լ� ���� ========>");
		int result = Rmmapper.menuupdatesOk(sno);
		return result;
	}

	@Override
	public int userIdCheck(String sid) {
		System.out.println("Rm_ServiceImpl userIdCheck�Լ� ���� ========>");
		int result = Rmmapper.userIdCheck(sid);
		return result;
	}
	
	@Override
	public int masterIdCheck(String sid) {
		System.out.println("Rm_ServiceImpl masterIdCheck�Լ� ���� ========>");
		int result = Rmmapper.masterIdCheck(sid);
		return result;
	}

	   @Override
	   public List<semmenuVO> MasterMain_list(RmSearchCondition rsc) {
	      // TODO Auto-generated method stub
	      System.out.println("===========Rm_ServiceImpl MasterMain_list �Լ� ���� ===========");
	      List<semmenuVO> RmList = Rmmapper.MasterMain_list(rsc);
	      System.out.println("RmList >>" + RmList);
	      return RmList;
	   }
}
