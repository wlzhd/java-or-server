package kr.sem.java.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import kr.sem.java.service.Rm_Service;
import kr.sem.java.vo.semVO;
import kr.sem.java.vo.semmenuVO;

@Controller
public class MM_Controller {

   @Autowired
   Rm_Service RmService;

   @RequestMapping(value = "/master/Ms_List")
   public List<semmenuVO> MasterMs_List(Model model, String sno) throws Exception {
      System.out.println("MS_Controller/MasterMs_List �Լ� ����");
      System.out.println("sno > " + sno);
      List<semmenuVO> mList = RmService.MasterMs_List(sno);
      System.out.println("mList >>" + mList);
      model.addAttribute("mList", mList);
      return null;
   }

   @RequestMapping(value = "/master/Mm_List")
   public String MasterMmOneList(@RequestParam(required = true) String sno, Model model) {
      System.out.println("MM_Controller/MasterMmOneList");
      System.out.println("sno >>" + sno);
      List<semVO> MmdList = RmService.MasterMmOneList(sno);
      System.out.println("MmdList >>" + MmdList);
      model.addAttribute("MmdList", MmdList);
      return "/master/Mm_List";
   }

   // ������ �ð� ����
   @RequestMapping(value = "/master/time")
   @ResponseBody
   public String MasterTime(@RequestParam String s_time, String s_no, Model model) {
      System.out.println("MM_Controller/MasterTime");
      
      System.out.println("s_time >> " + s_time);
      
      semmenuVO sno = new semmenuVO();
      sno.setS_time(s_time);
      sno.setS_mno(s_no);
      int Timeresult = RmService.MasterTime(sno);
      System.out.println("Timeresult > " + Timeresult);
      model.addAttribute("Timeresult", Timeresult);
//    String res = String.valueOf(Timeresult);
      return "null";
   }

   @RequestMapping(value = "/master/table")
   public String MasterTable(@RequestParam String s_seat, String s_no, Model model) {
      System.out.println("MM_Controller/MasterTable");
      semmenuVO sno = new semmenuVO();
      sno.setS_seat(s_seat);
      sno.setS_mno(s_no);
      int Tableresult = RmService.MasterTable(sno);
      System.out.println("Tableresult >" + Tableresult);
      // model.addAttribute("Tableresult", Tableresult);
      String res = String.valueOf(Tableresult);
      return res;
   }

}