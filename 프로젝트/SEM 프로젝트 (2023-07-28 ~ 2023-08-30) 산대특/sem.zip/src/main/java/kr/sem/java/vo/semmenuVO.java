package kr.sem.java.vo;

import lombok.Data;

@Data
public class semmenuVO {
   
   private String s_mno;
   private String s_sno; 
   private String s_path; 
   private String s_waiting; 
   private String s_time; 
   private String s_seat; 
   private String s_mname;
   private String s_mprice; 
   private String s_orgfname; 
   private String s_refname; 
   private String s_imagepath; 
   private String s_inserttime;
}