package kr.sem.java.vo;

import lombok.Data;

@Data
public class semVO {
   private String s_no;
   private String s_id;
   private String s_pass;
   private String s_post;
   private String s_addr1;
   private String s_addr2;
   private String s_gender;
   private String s_birth;
   private String s_name;
   private String s_email;
   private String s_storephone;
   private String s_phone;
   private String s_morgfnmae;
   private String s_mrefname;
   private String s_mfpath;
   private String s_image;
   private String s_insertdate;
   private String s_deletedate;
   private String s_authority;
}