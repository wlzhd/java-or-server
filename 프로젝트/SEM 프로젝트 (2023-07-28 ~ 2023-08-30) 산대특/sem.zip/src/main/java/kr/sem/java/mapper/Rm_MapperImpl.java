package kr.sem.java.mapper;

import java.util.List;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import kr.sem.java.vo.RmSearchCondition;
import kr.sem.java.vo.semVO;
import kr.sem.java.vo.semmenuVO;

@Repository
public class Rm_MapperImpl implements Rm_Mapper { // ����� ����� ���� �Դϴ�
	@Autowired
	private SqlSession session;
	private static String namespace = "kr.sem.java.sql.RmSqlMap.";

	   @Override
	   public int menuRmDelete(String sno) {
	      // TODO Auto-generated method stub
	      System.out.println("Rm_MapperImpl menuRmDelete �Լ� ���� =======");
	      return session.delete(namespace + "menuRmDelete", sno);
	   }

	@Override
	public int getPageCnt(RmSearchCondition rsc) {
		// TODO Auto-generated method stub
		System.out.println("RmMapperImpl getPageCnt�Լ� ���� =======><<<><><><");
		return session.selectOne(namespace + "getPageCnt", rsc);
	}

	// ======================���̵� ã��========================

	public List<semVO> idCheck(semVO sno) throws Exception {
		System.out.println("Rm_MapperImpl idCheck �Լ� ����");
		return session.selectList(namespace + "idCheck", sno);
	}

	// ======================��й�ȣ ã��========================

	public List<semVO> pwCheck(semVO sno) throws Exception {
		// System.out.println("sno > " + sno);
		System.out.println("Rm_MapperImpl pwCheck �Լ� ����");
		return session.selectList(namespace + "pwCheck", sno);
	}

	@Override
	public int passUpdate(semVO sno) {
		// TODO Auto-generated method stub
		System.out.println("Rm_Mapper passUpdate �Լ����� --------------");
		return session.update(namespace + "passUpdate", sno);
	}
	// =====================================================

	@Override
	public int MasterTime(semmenuVO sno) {
		// TODO Auto-generated method stub
		System.out.println("Rm_MapperImpl MasterTime �Լ� ���� =======");
		System.out.println(sno);
		return session.update(namespace + "MasterTime", sno);
	}

	@Override
	public int MasterTable(semmenuVO sno) {
		// TODO Auto-generated method stub
		System.out.println("Rm_MapperImpl MasterTable �Լ� ���� =======");
		System.out.println(sno);
		return session.update(namespace + "MasterTable", sno);
	}

	// =====================================================

	public List<semVO> RmselectAllBoard() {
		// TODO Auto-generated method stub
		System.out.println("==================== Rm_MapperImpl RmselectAllBoard�Լ� ���� =========================");
		return session.selectList(namespace + "RmselectAllBoard");
	}

	@Override
	public List<semVO> RmselectOneBoard(String sno) {
		// TODO Auto-generated method stub
		System.out.println("==================== Rm_MapperImpl RmselectOneBoard�Լ� ���� =========================");
		return session.selectList(namespace + "RmselectOneBoard", sno);
	}

	// ========================================================================================================
	public List<semVO> RuselectAllBoard() {
		// TODO Auto-generated method stub
		System.out.println("==================== Ru_MapperImpl RuselectAllBoard�Լ� ���� =========================");
		return session.selectList(namespace + "RuselectAllBoard");
	}

	@Override
	public List<semVO> RuselectOneBoard(String sno) {
		// TODO Auto-generated method stub
		System.out.println("==================== Ru_MapperImpl RuselectOneBoard�Լ� ���� =========================");
		return session.selectList(namespace + "RuselectOneBoard", sno);
	}

	// ========================================================================================================
	@Override
	public List<semVO> RmDeleteCheckBoard() {
		// TODO Auto-generated method stub
		System.out.println("==================== Ru_MapperImpl RmDeleteCheckBoard�Լ� ���� =========================");
		return session.selectList(namespace + "RmDeleteCheckBoard");
	}

	@Override
	public List<semVO> RmDeleteCheckOneBoard(String sno) {
		// TODO Auto-generated method stub
		System.out.println("==================== Ru_MapperImpl RmDeleteCheckOneBoard�Լ� ���� =========================");
		return session.selectList(namespace + "RmDeleteCheckOneBoard", sno);
	}

	// ========================================================================================================
	@Override
	public List<semVO> loginselect(semVO user) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("===================Rm_MapperImpl loginselect===================");
		// System.out.println(user.getUid());
		return session.selectList(namespace + "loginselect", user);
	}

	// ========================================================================================================
	@Override
	public semVO read(String sno) {
		// TODO Auto-generated method stub
		System.out.println("==================== Ru_MapperImpl read�Լ� ���� =========================");
		return (semVO) session.selectList(namespace + "read", sno);
	}

	// ========================================================================================================
	@Override
	public int RmuUpdate(semVO sno) {
		// TODO Auto-generated method stub
		System.out.println("Rm_MapperImpl RmuUpdate �Լ� ���� =======");
		return session.update(namespace + "RmuUpdate", sno);
	}

	@Override
	public int UpdateBoard(semVO svo) {
		// TODO Auto-generated method stub
		System.out.println("Rm_MapperImpl UpdateBoard �Լ� ���� =======");
		return session.update(namespace + "updateBoard", svo);
	}

	@Override
	public int UUpdateBoard(semVO svo) {
		// TODO Auto-generated method stub
		System.out.println("Rm_MapperImpl UUpdateBoard �Լ� ���� =======");
		return session.update(namespace + "uupdateBoard", svo);
	}

	// ========================================================================================================
	@Override
	public int userInsert(semVO sno) {
		// TODO Auto-generated method stub
		System.out.println("UserMapper userInsert �Լ����� --------------");
		return session.insert(namespace + "userInsert", sno);
	}

	// ========================================================================================================
	@Override
	public String userCommNo() {
		// TODO Auto-generated method stub
		System.out.println("UserMapper userCommNO �Լ����� --------------");
		int result = session.selectOne(namespace + "userCommNO");
		String maxno = String.valueOf(result);
		return maxno;
	}

	// ========================================================================================================
	@Override
	public int RmDelete(String sno) {
		// TODO Auto-generated method stub
		System.out.println("Rm_MapperImpl RmDelete �Լ� ���� =======");
		return session.update(namespace + "RmDelete", sno);
	}

	@Override
	public int RmreallyDelete(String sno) {
		// TODO Auto-generated method stub
		System.out.println("==================== Rm_MapperImpl RmreallyDelete�Լ� ���� =========================");
		System.out.println("sno >>" + sno);
		return session.delete(namespace + "RmreallyDelete", sno);
	}

	@Override
	public String masterCommNo() {
		// TODO Auto-generated method stub
		System.out.println("Rm_Mapper masterCommNO �Լ����� --------------");
		int result = session.selectOne(namespace + "masterCommNO");
		String maxno = String.valueOf(result);
		return maxno;
	}

	@Override
	public int masterInsert(semVO sno) {
		// TODO Auto-generated method stub
		System.out.println("UserMapper masterInsert �Լ����� --------------");
		return session.insert(namespace + "masterInsert", sno);
	}

	// ========================================================================================================
	@Override
	public List<semVO> MasterMmOneList(String sno) {
		// TODO Auto-generated method stub
		System.out.println("==================== Rm_MapperImpl MasterMmOneList =========================");
		return session.selectList(namespace + "MasterMmOneList", sno);
	}

	// =============================================================
	@Override
	public List<semVO> uselectOneBoard(String sno) {
		// TODO Auto-generated method stub
		System.out.println("==================== Ru_MapperImpl uselectOneBoard�Լ� ���� =========================");
		return session.selectList(namespace + "uselectOneBoard", sno);
	}

	@Override
	public int menuInsert(semmenuVO sno) {
		System.out.println("UserMapper menuInsert �Լ����� --------------");
		return session.insert(namespace + "menuInsert", sno);
	}

	@Override
	public List<semmenuVO> MasterMs_List(String s_mno) {
		// TODO Auto-generated method stub
		System.out.println("==================== Rm_MapperImpl MasterMs_List�Լ� ���� =========================");
		return session.selectList(namespace + "MasterMs_List", s_mno);
	}

	@Override
	public List<semmenuVO> MasterMain_list() {
		System.out.println("==================== Rm_MapperImpl MasterMain_list�Լ� ���� =========================");
		return session.selectList(namespace + "MasterMain_list");
	}

	@Override
	public List<semmenuVO> MasterMain2_list(String s_sno) {
		System.out.println("==================== Rm_MapperImpl MasterMain2_list�Լ� ���� =========================");
		return session.selectList(namespace + "MasterMain2_list", s_sno);
	}

	@Override
	public int menudelete(String s_no) {
		// TODO Auto-generated method stub
		System.out.println("==================== Rm_MapperImpl menudelete�Լ� ���� =========================");
		System.out.println("s_no >>" + s_no);
		return session.delete(namespace + "menudelete", s_no);
	}

	@Override
	public List<semmenuVO> MeselectOneList(String s_sno) {
		System.out.println("==================== Rm_MapperImpl MeselectOneList�Լ� ���� =========================");
		return session.selectList(namespace + "MeselectOneList", s_sno);
	}

	@Override
	public int menuupdatesOk(semmenuVO sno) {
		// TODO Auto-generated method stub
		System.out.println("Rm_MapperImpl menuupdatesOk �Լ� ���� =======>");
		return session.update(namespace + "menuupdatesOk", sno);
	}

	@Override
	public int userIdCheck(String sid) {
		System.out.println("Rm_MapperImpl userIdCheck �Լ� ���� =======>");
		return session.selectOne(namespace + "userIdCheck", sid);
	}

	@Override
	public int masterIdCheck(String sid) {
		System.out.println("Rm_MapperImpl userIdCheck �Լ� ���� =======>");
		return session.selectOne(namespace + "userIdCheck", sid);
	}
	
	@Override
	public List<semmenuVO> MasterMain_list(RmSearchCondition rsc) {
		// TODO Auto-generated method stub
		System.out.println("==================== Rm_MapperImpl MasterMain_list�Լ� ���� =========================");
		return session.selectList(namespace + "MasterMain_list", rsc);
	}

}