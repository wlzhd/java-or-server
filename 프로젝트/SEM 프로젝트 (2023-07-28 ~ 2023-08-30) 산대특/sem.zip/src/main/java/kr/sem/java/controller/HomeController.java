package kr.sem.java.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import kr.sem.java.service.Rm_Service;
import kr.sem.java.vo.PageHandler;
import kr.sem.java.vo.RmSearchCondition;
import kr.sem.java.vo.semmenuVO;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	   private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	   @Autowired
	   Rm_Service RmService;
	   @RequestMapping(value = "/", method = RequestMethod.GET)
	   public String home(@ModelAttribute RmSearchCondition rsc, Model model) {   
	      System.out.println("HomeController/MasterMain_list �Լ� ����");
	      System.out.println("option >>" +rsc.getOption());
	      System.out.println("Keyword >>" +rsc.getKeyword());
	      List<semmenuVO> mList = RmService.MasterMain_list(rsc);
	      
	      int totalCnt = RmService.getPageCnt(rsc);
	      PageHandler ph = new PageHandler(totalCnt, rsc);
	      
	      System.out.println("mList >>" + mList);
	      model.addAttribute("mList", mList);
	      
	      //��ȯ�Ǵ� ���Ͽ� ������ �� ��ȯ�ϱ� ���ؼ� model Ÿ�� ���
	      model.addAttribute("totalCnt", totalCnt);
	      model.addAttribute("ph", ph);
	      
	      return "home";
	   }
	@RequestMapping(value = "/home/menu")
	@ResponseBody
	public List<semmenuVO> home2(Model model, @RequestParam(required=true) String s_mno) {	
		System.out.println("HomeController/MasterMain2_list �Լ� ����");
		System.out.println("s_sno >> " + s_mno);
		List<semmenuVO> mmList = RmService.MasterMain2_list(s_mno);
		System.out.println("s_sno >> " + s_mno);
		System.out.println("mmList >>" + mmList);
		model.addAttribute("mmList", mmList);
		return mmList;
	}
}
