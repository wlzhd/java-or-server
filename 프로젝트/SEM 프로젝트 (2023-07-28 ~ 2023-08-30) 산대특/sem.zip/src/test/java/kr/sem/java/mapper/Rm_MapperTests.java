package kr.sem.java.mapper;

import java.util.ArrayList;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import kr.sem.java.vo.semVO;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class Rm_MapperTests {
   @Setter(onMethod_ = {@Autowired})
   private Rm_Mapper mapper;
 
   @Test
   public void testSelectAllBoards() {
      mapper.RmselectAllBoard().forEach(board -> log.info(board));
   }
   /*
   @Test
   public void testinsertBoard() {
      BoardVO bVo = new BoardVO();
      bVo.setIdx(38);
      bVo.setName("���ϱ�");
      bVo.setSubject("����");
      bVo.setContent("����");
      bVo.setRegdate("2023-01-01");
      bVo.setHit(1);
      bVo.setIp("172.0.0.2");
      mapper.InsertBoard(bVo);
      log.info("asdfsadgdsagasds");
   }*/
   /*@Test
   public void testSelectOneBoardByNum() {
      BoardVO bVo = mapper.SelectOneBoardByNum(32);
      log.info(bVo);
   }*/
   /*
   @Test
      public void testDeleteBoard() {
         mapper.deleteBoard(31);
      }*/
     /*
      @Test
      public void testUpdateBoard() {
         BoardVO bVo = new BoardVO();
         bVo.setIdx(29);
         bVo.setName("�̱���");
         bVo.setSubject("���� �̾߱�");
         bVo.setContent("���� �̾߱�");
         mapper.updateBoard(bVo);
         log.info(bVo);
      }
      */
}

